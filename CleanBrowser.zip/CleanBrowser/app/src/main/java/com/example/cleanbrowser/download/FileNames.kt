package com.example.cleanbrowser.download

object FileNames {
    /** Cleans a title into a base name (no extension). Keeps punctuation and Unicode. */
    fun base(raw: String): String {
        var s = raw
            .replace(":", " -").replace("|", "-")
            .replace(Regex("[\\\\/*?\"<>\\p{Cntrl}]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        // Never double the extension: "clip.mp4" and "clip.MP4.mp4" both become "clip".
        while (s.endsWith(".mp4", ignoreCase = true)) s = s.dropLast(4).trimEnd()
        s = s.trim('.', ' ').take(150).trim()
        return s.ifBlank { "video" }
    }

    /** The saved file name. Always ends with .mp4. */
    fun full(raw: String): String = base(raw) + ".mp4"
}
