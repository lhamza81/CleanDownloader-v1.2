package com.example.cleanbrowser.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedTab(val url: String, val title: String)
data class SavedSession(val tabs: List<SavedTab>, val active: Int)

/** Saves open tabs (URL + title only) so they come back after the process is killed. */
object TabStore {
    private const val PREFS = "session"
    private const val KEY = "json"

    fun save(ctx: Context, mgr: TabManager) {
        val arr = JSONArray()
        mgr.tabs.forEach { arr.put(JSONObject().put("u", it.url).put("t", it.title)) }
        val active = mgr.tabs.indexOfFirst { it.id == mgr.activeId }.coerceAtLeast(0)
        val json = JSONObject().put("tabs", arr).put("active", active).toString()
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply()
    }

    fun load(ctx: Context): SavedSession? {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return null
        return try {
            val o = JSONObject(raw)
            val arr = o.getJSONArray("tabs")
            val tabs = (0 until arr.length()).map {
                val t = arr.getJSONObject(it)
                SavedTab(t.getString("u"), t.optString("t", "Tab"))
            }
            SavedSession(tabs, o.optInt("active", 0)).takeIf { tabs.isNotEmpty() }
        } catch (e: Exception) { null }
    }
}
