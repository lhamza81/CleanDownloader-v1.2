package com.example.cleanbrowser.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.Fmt
import com.example.cleanbrowser.download.DlState
import com.example.cleanbrowser.download.DownloadItem
import com.example.cleanbrowser.download.DownloadStore
import com.example.cleanbrowser.download.Downloader
import com.example.cleanbrowser.download.FileNames

enum class DownloadsMode { Active, Completed }

/** Active: downloading / paused / failed. Completed: finished files. One video per card. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(mode: DownloadsMode, onPlay: (DownloadItem) -> Unit) {
    val all by DownloadStore.items.collectAsState()
    val list = all.filter { (it.state == DlState.COMPLETED) == (mode == DownloadsMode.Completed) }

    Scaffold(
        topBar = { TopAppBar(title = { Text(if (mode == DownloadsMode.Active) "Downloads" else "Completed") }) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        if (list.isEmpty()) {
            Text(
                if (mode == DownloadsMode.Active) "No active downloads" else "No completed downloads yet",
                modifier = Modifier.padding(padding).padding(24.dp),
            )
        }
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(list, key = { it.id }) { item -> DownloadCard(item) { onPlay(item) } }
        }
    }
}

@Composable
private fun DownloadCard(item: DownloadItem, onPlay: () -> Unit) {
    val ctx = LocalContext.current
    val done = item.state == DlState.COMPLETED
    val uri = remember(item.uri) { item.uri?.let { Uri.parse(it) } }
    val info by rememberMediaInfo(if (done) uri else null)
    val frame = info?.frame

    val sizeText = (info?.sizeBytes ?: item.total.takeIf { it > 0 })?.let { Fmt.size(it) }
    val meta = listOfNotNull(sizeText, info?.durationSec?.let { Fmt.duration(it) }).joinToString(" · ")

    val progressText = when {
        item.total > 0 -> "${Fmt.size(item.downloaded)} / ${Fmt.size(item.total)} · " +
            "${(item.downloaded * 100 / item.total).coerceIn(0, 100)}%"
        item.downloaded > 0 -> Fmt.size(item.downloaded)
        else -> ""
    }
    val status = when (item.state) {
        DlState.DOWNLOADING -> listOf("Downloading", progressText)
        DlState.PAUSED -> listOf("Paused", progressText)
        DlState.FAILED -> listOf(item.error ?: "Failed", "press play to retry")
        DlState.COMPLETED -> emptyList()
    }.filter { it.isNotEmpty() }.joinToString(" · ")

    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .padding(8.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            // Preview (finished files) with a play overlay.
            Box(
                Modifier.width(112.dp).height(72.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .then(if (done) Modifier.clickable(onClick = onPlay) else Modifier),
                contentAlignment = Alignment.Center,
            ) {
                if (frame != null) {
                    Image(frame.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Icon(if (done) Icons.Filled.PlayArrow else Icons.Filled.Download, null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (done && frame != null) {
                    Icon(Icons.Filled.PlayArrow, "Play", tint = Color.White,
                        modifier = Modifier.size(28.dp).background(Color.Black.copy(alpha = 0.45f), CircleShape))
                }
            }
            Column(Modifier.weight(1f).padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                // Full name, always ending in .mp4
                Text(FileNames.full(item.name), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                if (done && meta.isNotEmpty()) {
                    Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (!done && status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodySmall)
                if (!done && item.total > 0) {
                    LinearProgressIndicator(
                        progress = { (item.downloaded.toFloat() / item.total).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    )
                }
            }
        }

        // Link + actions
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                item.url,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(start = 4.dp),
            )
            when (item.state) {
                DlState.COMPLETED -> IconButton(onClick = onPlay) { Icon(Icons.Filled.PlayArrow, "Play") }
                DlState.DOWNLOADING -> IconButton(onClick = { Downloader.pause(ctx, item.id) }) { Icon(Icons.Filled.Pause, "Pause") }
                else -> IconButton(onClick = { Downloader.resume(ctx, item.id) }) { Icon(Icons.Filled.PlayArrow, "Resume") }
            }
            IconButton(onClick = {
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("link", item.url))
                Toast.makeText(ctx, "Link copied", Toast.LENGTH_SHORT).show()
            }) { Icon(Icons.Filled.ContentCopy, "Copy link") }
            IconButton(onClick = { Downloader.remove(ctx, item) }) { Icon(Icons.Filled.Delete, "Delete") }
        }
    }
}
