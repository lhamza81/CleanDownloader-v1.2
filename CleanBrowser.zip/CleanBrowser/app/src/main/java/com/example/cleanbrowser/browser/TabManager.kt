package com.example.cleanbrowser.browser

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Patterns
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Owns up to [MAX_TABS] tabs. Only [MAX_LIVE_WEBVIEWS] WebViews exist at once (LRU);
 * older ones are serialized with saveState() and destroyed, then lazily rebuilt when selected.
 */
class TabManager(private val appContext: Context) {

    companion object {
        const val MAX_TABS = 30
        const val MAX_LIVE_WEBVIEWS = 10
        const val HOME = "https://www.google.com"
    }

    val tabs = mutableStateListOf<BrowserTab>()
    var activeId by mutableIntStateOf(-1)
        private set
    val activeTab: BrowserTab? get() = tabs.firstOrNull { it.id == activeId }

    var userAgent: String = ""
        private set

    // Fullscreen video (WebChromeClient custom view)
    var customView by mutableStateOf<View?>(null)
        private set
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    fun exitFullscreen() {
        customCallback?.onCustomViewHidden()
        customCallback = null
        customView = null
    }

    /** Recreates tabs from a saved session. WebViews are built lazily, so only the active one costs memory. */
    fun restore(session: SavedSession) {
        session.tabs.take(MAX_TABS).forEach { st ->
            tabs.add(BrowserTab(nextId++, st.url).also { it.title = st.title })
        }
        if (tabs.isEmpty()) { newTab(); return }
        select(tabs[session.active.coerceIn(0, tabs.lastIndex)].id)
    }

    private var nextId = 1
    private val mainHandler = Handler(Looper.getMainLooper())

    // accessOrder = true -> iteration order is least-recently-used first
    private val live = LinkedHashMap<Int, WebView>(8, 0.75f, true)

    // ---------- tab lifecycle ----------

    // Link long-press menu (URL of the pressed link, or null)
    var linkMenu by mutableStateOf<String?>(null)
        private set
    fun dismissLinkMenu() { linkMenu = null }

    private val hrefHandler = Handler(Looper.getMainLooper()) { m ->
        m.data?.getString("url")?.takeIf { it.isNotBlank() }?.let { linkMenu = it }
        true
    }

    /** @return false if the 30-tab limit is reached. */
    fun newTab(url: String = HOME, popup: Boolean = false): Boolean {
        if (tabs.size >= MAX_TABS) return false
        val tab = BrowserTab(nextId++, url).also { it.isPopup = popup }
        tabs.add(tab)
        select(tab.id)
        return true
    }

    fun select(id: Int) {
        if (id == activeId) return
        live[activeId]?.onPause()
        activeId = id
        tabs.firstOrNull { it.id == id }?.let { webViewFor(it).onResume() }
        trimLive()
    }

    fun closeTab(id: Int) {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        live.remove(id)?.let { destroy(it) }
        tabs.removeAt(index)
        when {
            tabs.isEmpty() -> { activeId = -1; newTab() }
            id == activeId -> { activeId = -1; select(tabs[minOf(index, tabs.lastIndex)].id) }
        }
    }

    fun destroyAll() {
        live.values.forEach { destroy(it) }
        live.clear()
        tabs.clear()
    }

    // ---------- WebView access ----------

    /** Returns the tab's WebView, creating/restoring it if it was freed. Detached from any old parent. */
    fun webViewFor(tab: BrowserTab): WebView {
        val wv = live[tab.id] ?: createWebView(tab).also { live[tab.id] = it }
        (wv.parent as? ViewGroup)?.removeView(wv)
        return wv
    }

    fun activeWebView(): WebView? = live[activeId]

    fun goBack() { activeWebView()?.takeIf { it.canGoBack() }?.goBack() }
    fun goForward() { activeWebView()?.takeIf { it.canGoForward() }?.goForward() }
    fun reload() { activeWebView()?.reload() }

    fun load(input: String) {
        val url = resolveInput(input)
        activeTab?.url = url
        activeWebView()?.loadUrl(url)
    }

    fun resolveInput(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return HOME
        if (!s.contains(' ') && Patterns.WEB_URL.matcher(s).matches()) {
            return if (s.startsWith("http://") || s.startsWith("https://")) s else "https://$s"
        }
        return "https://www.google.com/search?q=" + Uri.encode(s)
    }

    // ---------- memory management ----------

    private fun trimLive() {
        val it = live.entries.iterator()
        while (live.size > MAX_LIVE_WEBVIEWS && it.hasNext()) {
            val (id, wv) = it.next()
            if (id == activeId) continue
            tabs.firstOrNull { t -> t.id == id }?.savedState = Bundle().also { b -> wv.saveState(b) }
            destroy(wv)
            it.remove()
        }
    }

    private fun destroy(wv: WebView) {
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.stopLoading()
        wv.webViewClient = WebViewClient()
        wv.webChromeClient = null
        wv.destroy()
    }

    // ---------- WebView construction ----------

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: BrowserTab): WebView {
        // Application context avoids leaking the Activity; swap to MutableContextWrapper later if you need dialogs.
        val wv = WebView(appContext)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = false
            allowContentAccess = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            setSupportMultipleWindows(true)
            builtInZoomControls = true
            displayZoomControls = false
            // Drop the "; wv" WebView marker so sites serve the normal mobile page.
            userAgentString = userAgentString.replace("; wv", "").replace(" Version/4.0", "")
            if (userAgent.isEmpty()) userAgent = userAgentString
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.webViewClient = client(tab)
        wv.webChromeClient = chrome(tab)
        wv.setOnLongClickListener { v ->
            val r = (v as WebView).hitTestResult
            when (r.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> r.extra?.let { linkMenu = it; true } ?: false
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> { v.requestFocusNodeHref(hrefHandler.obtainMessage()); true }
                else -> false
            }
        }

        val restored = tab.savedState?.let { wv.restoreState(it) }
        tab.savedState = null
        if (restored == null && !tab.isPopup) wv.loadUrl(tab.url)
        tab.isPopup = false
        return wv
    }

    private fun sync(tab: BrowserTab, wv: WebView) {
        tab.canGoBack = wv.canGoBack()
        tab.canGoForward = wv.canGoForward()
        wv.title?.takeIf { it.isNotBlank() }?.let { tab.title = it }
        wv.url?.let { tab.url = it }
    }

    private fun client(tab: BrowserTab) = object : WebViewClient() {
        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            tab.url = url
            tab.videos.clear()
            tab.favicon = favicon ?: tab.favicon
            sync(tab, view)
        }

        override fun onPageFinished(view: WebView, url: String) = sync(tab, view)

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) = sync(tab, view)

        // Runs on a background thread. We only observe; returning null lets WebView load normally.
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            VideoDetector.classify(request.url.toString())?.let { video ->
                mainHandler.post { tab.addVideo(video) }
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val scheme = request.url.scheme?.lowercase()
            return scheme != "http" && scheme != "https" && scheme != "about"
        }
    }

    private fun chrome(tab: BrowserTab) = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) { tab.progress = newProgress }
        override fun onReceivedTitle(view: WebView, title: String?) { if (!title.isNullOrBlank()) tab.title = title }
        override fun onReceivedIcon(view: WebView, icon: Bitmap?) { tab.favicon = icon }

        // target=_blank / window.open triggered by a tap opens a new tab; scripted popups are ignored.
        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
            if (!isUserGesture || !newTab("about:blank", popup = true)) return false
            val wv = activeWebView() ?: return false
            (resultMsg.obj as WebView.WebViewTransport).webView = wv
            resultMsg.sendToTarget()
            return true
        }

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            customCallback?.onCustomViewHidden()
            customView = view
            customCallback = callback
        }

        override fun onHideCustomView() {
            customView = null
            customCallback = null
        }
    }
}
