package com.example.cleanbrowser.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.webkit.CookieManager
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.cleanbrowser.browser.Fmt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Downloads one MP4 straight into Downloads (MediaStore). Pause = cancel this worker and keep the
 * partial file; Resume = start it again and continue from the saved size with an HTTP Range request.
 */
class Mp4DownloadWorker(ctx: android.content.Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    companion object {
        const val K_ID = "id"
        const val CHANNEL = "downloads"
        fun workName(id: String) = "dl_$id"
    }

    private val itemId: String get() = inputData.getString(K_ID).orEmpty()
    private var title = "Download"

    override suspend fun getForegroundInfo() = foreground(0, "Starting…")

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        DownloadStore.init(applicationContext)
        val item = DownloadStore.get(itemId) ?: return@withContext Result.failure()
        title = FileNames.full(item.name)
        DownloadStore.change(itemId) { it.copy(state = DlState.DOWNLOADING, error = null) }
        try {
            setForeground(foreground(0, "Downloading…"))
            download(item)
            Result.success()
        } catch (e: Exception) {
            if (e is CancellationException || isStopped) {
                // Paused by the user (or stopped by the system): keep the partial file for resuming.
                DownloadStore.change(itemId) {
                    if (it.state == DlState.DOWNLOADING) it.copy(state = DlState.PAUSED) else it
                }
                if (e is CancellationException) throw e
                Result.failure()
            } else {
                DownloadStore.change(itemId) { it.copy(state = DlState.FAILED, error = e.message ?: "Download failed") }
                Result.failure()
            }
        }
    }

    // ---------- download ----------

    private suspend fun download(item: DownloadItem) {
        val resolver = applicationContext.contentResolver

        // Continue an existing partial file, or start a new one.
        val existing = item.uri?.let { Uri.parse(it) }
        var offset = existing?.let { u ->
            runCatching { resolver.openFileDescriptor(u, "r")?.use { it.statSize } }.getOrNull()
        } ?: -1L
        val target: Uri = if (existing != null && offset >= 0) existing else {
            offset = 0L
            createPending(FileNames.full(item.name)).also { u ->
                DownloadStore.change(itemId) { it.copy(uri = u.toString()) }
            }
        }

        val conn = open(item, offset)
        try {
            val code = conn.responseCode
            if (code == 416 && offset > 0) { finish(target, item); return }   // already complete
            var append = offset > 0
            if (append && code == 200) { append = false; offset = 0L }          // server ignored Range: restart
            else if (code !in 200..299) throw IOException("HTTP $code")

            val total = if (code == 206)
                conn.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1L
            else conn.contentLengthLong
            DownloadStore.change(itemId, persist = false) { it.copy(downloaded = offset, total = total) }

            coroutineScope {
                // Closing the connection is what makes a blocked read stop quickly when paused.
                val watcher = launch { try { awaitCancellation() } finally { conn.disconnect() } }
                try { copy(conn, target, append, offset, total) } finally { watcher.cancel() }
            }
            finish(target, item)
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun copy(conn: HttpURLConnection, uri: Uri, append: Boolean, startAt: Long, total: Long) {
        var done = startAt
        var lastTick = 0L
        applicationContext.contentResolver.openFileDescriptor(uri, if (append) "wa" else "wt")!!.use { pfd ->
            FileOutputStream(pfd.fileDescriptor).use { out ->
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastTick >= 500) {
                            lastTick = now
                            DownloadStore.change(itemId, persist = false) { it.copy(downloaded = done, total = total) }
                            val pct = if (total > 0) (done * 100 / total).toInt() else 0
                            val text = if (total > 0) "${Fmt.size(done)} / ${Fmt.size(total)}" else Fmt.size(done)
                            setForeground(foreground(pct, text))
                        }
                    }
                    out.flush()
                }
            }
        }
        if (total > 0 && done < total) throw IOException("Connection lost")
        DownloadStore.change(itemId, persist = false) { it.copy(downloaded = done) }
    }

    private fun open(item: DownloadItem, offset: Long): HttpURLConnection {
        val c = URL(item.url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.setRequestProperty("User-Agent", item.userAgent)
        c.setRequestProperty("Referer", item.pageUrl)
        c.setRequestProperty("Accept-Encoding", "identity")
        runCatching { CookieManager.getInstance().getCookie(item.url) }.getOrNull()
            ?.let { c.setRequestProperty("Cookie", it) }
        if (offset > 0) c.setRequestProperty("Range", "bytes=$offset-")
        return c
    }

    // ---------- file + notifications ----------

    private fun createPending(fileName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)           // always ends with .mp4
            put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return applicationContext.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Couldn't create the file")
    }

    private fun finish(uri: Uri, item: DownloadItem) {
        val resolver = applicationContext.contentResolver
        resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        val size = runCatching { resolver.openFileDescriptor(uri, "r")?.use { it.statSize } }.getOrNull() ?: 0L
        DownloadStore.change(itemId) { it.copy(state = DlState.COMPLETED, downloaded = size, total = size) }
        DownloadStore.completed.tryEmit(FileNames.full(item.name))

        val done = Notification.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(FileNames.full(item.name))
            .setContentText("Download complete")
            .setAutoCancel(true)
            .build()
        applicationContext.getSystemService(NotificationManager::class.java).notify(itemId.hashCode(), done)
    }

    private fun foreground(pct: Int, text: String): ForegroundInfo {
        val ctx = applicationContext
        ctx.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW))
        // Cancelling the worker = pause (the partial file is kept).
        val pause = WorkManager.getInstance(ctx).createCancelPendingIntent(id)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, pct == 0)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(ctx, android.R.drawable.ic_media_pause), "Pause", pause).build())
            .build()
        return ForegroundInfo(itemId.hashCode() + 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }
}
