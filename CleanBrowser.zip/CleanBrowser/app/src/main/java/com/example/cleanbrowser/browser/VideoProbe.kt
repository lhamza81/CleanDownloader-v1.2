package com.example.cleanbrowser.browser

import android.media.MediaMetadataRetriever
import android.webkit.CookieManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.min

/** What we know about a detected MP4 before downloading it. */
data class QualityOption(
    val label: String,            // "480p (854x480)"
    val url: String,
    val detail: String? = null,   // "45.23 MB · 12 min 34 sec"
    val sizeBytes: Long? = null,
    val seconds: Double? = null,
)

/** Reads resolution, size and length of an MP4 link without downloading it. */
object VideoProbe {

    suspend fun probe(video: DetectedVideo, ua: String, referer: String): QualityOption =
        withContext(Dispatchers.IO) {
            runCatching { read(video, ua, referer) }.getOrNull() ?: QualityOption("Original quality", video.url)
        }

    private fun read(video: DetectedVideo, ua: String, referer: String): QualityOption {
        var size = 0L
        runCatching {
            val c = open(video.url, ua, referer, "HEAD")
            size = c.contentLengthLong
            c.disconnect()
        }

        var w = 0
        var h = 0
        var seconds: Double? = null
        runCatching {
            val headers = mutableMapOf("User-Agent" to ua, "Referer" to referer)
            CookieManager.getInstance().getCookie(video.url)?.let { headers["Cookie"] = it }
            MediaMetadataRetriever().use { r ->
                r.setDataSource(video.url, headers)
                w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                seconds = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.takeIf { it > 0 }?.let { it / 1000.0 }
            }
        }

        val label = when {
            w > 0 && h > 0 -> "${min(w, h)}p (${w}x${h})"
            else -> Regex("(\\d{3,4})[pP]").find(video.url)?.let { "${it.groupValues[1]}p" } ?: "Original quality"
        }
        val sizeBytes = size.takeIf { it > 0 }
        val detail = listOfNotNull(sizeBytes?.let { Fmt.size(it) }, seconds?.let { Fmt.duration(it) })
            .joinToString(" · ").ifEmpty { null }
        return QualityOption(label, video.url, detail, sizeBytes, seconds)
    }

    private fun open(url: String, ua: String, referer: String, method: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 8_000
        c.readTimeout = 8_000
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Referer", referer)
        runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull()?.let { c.setRequestProperty("Cookie", it) }
        return c
    }
}
