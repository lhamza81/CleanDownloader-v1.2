package com.example.cleanbrowser.browser

import android.net.Uri

object VideoDetector {
    /** Only direct .mp4 files are detected (query string ignored). Safe to call off the main thread. */
    fun classify(url: String): DetectedVideo? {
        val path = Uri.parse(url).path?.lowercase() ?: return null
        return if (path.endsWith(".mp4")) DetectedVideo(url) else null
    }
}
