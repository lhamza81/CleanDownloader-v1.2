package com.example.cleanbrowser.download

import android.content.Context
import android.net.Uri
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.UUID

object Downloader {

    /** Adds the MP4 to the download list and starts it. The saved file always ends with .mp4. */
    fun enqueue(ctx: Context, url: String, pageUrl: String, userAgent: String, rawName: String) {
        DownloadStore.init(ctx)
        val item = DownloadItem(
            id = UUID.randomUUID().toString(),
            url = url, pageUrl = pageUrl, userAgent = userAgent,
            name = FileNames.base(rawName),
            state = DlState.DOWNLOADING, uri = null, downloaded = 0L, total = -1L,
            error = null, createdAt = System.currentTimeMillis(),
        )
        DownloadStore.add(item)
        start(ctx, item.id)
    }

    fun pause(ctx: Context, id: String) {
        DownloadStore.change(id) { it.copy(state = DlState.PAUSED) }
        WorkManager.getInstance(ctx).cancelUniqueWork(Mp4DownloadWorker.workName(id))
    }

    fun resume(ctx: Context, id: String) {
        DownloadStore.change(id) { it.copy(state = DlState.DOWNLOADING, error = null) }
        start(ctx, id)
    }

    /** Removes the entry and deletes the file (partial or complete). */
    fun remove(ctx: Context, item: DownloadItem) {
        WorkManager.getInstance(ctx).cancelUniqueWork(Mp4DownloadWorker.workName(item.id))
        item.uri?.let { runCatching { ctx.contentResolver.delete(Uri.parse(it), null, null) } }
        DownloadStore.remove(item.id)
    }

    private fun start(ctx: Context, id: String) {
        val req = OneTimeWorkRequestBuilder<Mp4DownloadWorker>()
            .setInputData(workDataOf(Mp4DownloadWorker.K_ID to id))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(Mp4DownloadWorker.workName(id), ExistingWorkPolicy.REPLACE, req)
    }
}
